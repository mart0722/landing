@echo off
setlocal
title EX2ToolsIV USB installer
if /i "%~1"=="--elevated" goto run
net session >nul 2>&1
if not errorlevel 1 goto run
echo Requesting administrator rights...
powershell -NoProfile -Command "Start-Process -FilePath '%~f0' -ArgumentList '--elevated' -WorkingDirectory '%~dp0' -Verb RunAs"
exit /b
:run
mode con: cols=100 lines=36 >nul 2>&1
chcp 65001 >nul
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0prepare-usb.ps1"
echo.
pause
endlocal
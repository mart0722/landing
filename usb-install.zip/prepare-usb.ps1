﻿#requires -version 5.1
<#
    prepare-usb.ps1 — записывает EX2ToolsIV на флешку и ПРОВЕРЯЕТ результат.

    Всё внутри: ни Git, ни Android SDK, ни openssl не нужны.
    Скрипт сам форматирует флешку в FAT32, копирует update.zip в
    3C6025_<версия>\OS\update.zip и проверяет: ФС, SHA-256, целостность zip,
    состав пакета и подпись (сверяется с ключом platform).

    Обычный запуск (двойной клик по write-usb.bat):
      .\prepare-usb.ps1

    Проверка уже записанной флешки без форматирования:
      .\prepare-usb.ps1 -Drive G -VerifyOnly

    Проверка папки на диске (для разработчика):
      .\prepare-usb.ps1 -Root D:\test-usb -VerifyOnly
#>
param(
    [string]$Drive,
    [string]$Root,
    [switch]$VerifyOnly,
    [string]$Folder = '3C6025_SW0E22H',
    [string]$Zip = ''
)

$ErrorActionPreference = 'Stop'
$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$folderName = $Folder
$expectedCertSha256 = 'C8A2E9BCCF597C2FB6DC66BEE293FC13F2FC47EC77BC6B2B0D52C11F51192AB8'
$useRoot = [bool]$Root

if (-not $Zip) { $Zip = Join-Path $scriptDir 'update.zip' }

# ------------------------------------------------------------- helpers ------

# Крупный шрифт в консоли: по умолчанию cmd показывает 8x16, на ноутбуке это мелко.
function Set-ConsoleFont {
    param([int]$Size = 22, [string]$Face = 'Consolas')
    try {
        if (-not ('Ex2ConsoleFont' -as [type])) {
            $src = @'
using System;
using System.Runtime.InteropServices;
public static class Ex2ConsoleFont {
    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
    public struct FONT_EX {
        public uint cbSize; public uint nFont; public short dwFontSizeX; public short dwFontSizeY;
        public int FontFamily; public int FontWeight;
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 32)] public string FaceName;
    }
    [DllImport("kernel32.dll", SetLastError = true, CharSet = CharSet.Unicode)]
    public static extern IntPtr CreateFile(string name, uint access, uint share, IntPtr sec, uint disp, uint flags, IntPtr templ);
    [DllImport("kernel32.dll", SetLastError = true, CharSet = CharSet.Unicode)]
    public static extern bool SetCurrentConsoleFontEx(IntPtr h, bool max, ref FONT_EX info);
    public static bool Apply(short size, string face) {
        IntPtr h = CreateFile("CONOUT$", 0x40000000 | 0x80000000, 3, IntPtr.Zero, 3, 0, IntPtr.Zero);
        if (h == IntPtr.Zero || h == new IntPtr(-1)) return false;
        FONT_EX info = new FONT_EX();
        info.cbSize = (uint)Marshal.SizeOf(typeof(FONT_EX));
        info.dwFontSizeY = size;
        info.FontFamily = 54;
        info.FontWeight = 400;
        info.FaceName = face;
        return SetCurrentConsoleFontEx(h, false, ref info);
    }
}
'@
            Add-Type -TypeDefinition $src -ErrorAction Stop
        }
        return [Ex2ConsoleFont]::Apply([int16]$Size, $Face)
    } catch {
        return $false
    }
}
[void](Set-ConsoleFont -Size 22 -Face 'Consolas')

function Test-Admin {
    $id = [Security.Principal.WindowsIdentity]::GetCurrent()
    $p = New-Object Security.Principal.WindowsPrincipal($id)
    return $p.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

function Get-RemovableDrives {
    Get-CimInstance Win32_LogicalDisk -Filter "DriveType=2" | ForEach-Object {
        [pscustomobject]@{
            Letter = $_.DeviceID.TrimEnd(':')
            Label  = $(if ($_.VolumeName) { $_.VolumeName } else { '(без имени)' })
            SizeGB = [math]::Round($_.Size / 1GB, 1)
            FreeGB = [math]::Round($_.FreeSpace / 1GB, 1)
            Fs     = $_.FileSystem
            Size   = $_.Size
        }
    }
}

function Get-VolumeInfo($letter) {
    Get-CimInstance Win32_LogicalDisk -Filter "DeviceID='$letter`:'"
}

$script:checks = New-Object System.Collections.Generic.List[object]
function Check([string]$name, [bool]$ok, [string]$detail = '') {
    $script:checks.Add([pscustomobject]@{ Name = $name; Ok = $ok; Detail = $detail })
    $mark = if ($ok) { '[ OK ]' } else { '[FAIL]' }
    $color = if ($ok) { 'Green' } else { 'Red' }
    $suffix = if ($detail) { " — $detail" } else { '' }
    Write-Host ("{0} {1}{2}" -f $mark, $name, $suffix) -ForegroundColor $color
}

function Show-Summary {
    $failed = @($script:checks | Where-Object { -not $_.Ok })
    Write-Host ''
    if ($failed.Count -eq 0) {
        Write-Host 'ВСЕ ПРОВЕРКИ ПРОЙДЕНЫ. Флешку можно вставлять в машину.' -ForegroundColor Green
        return 0
    }
    Write-Host ("ПРОВАЛЕНО ПРОВЕРОК: {0}. ФЛЕШКУ ИСПОЛЬЗОВАТЬ НЕЛЬЗЯ." -f $failed.Count) -ForegroundColor Red
    foreach ($f in $failed) { Write-Host ("  - {0} {1}" -f $f.Name, $f.Detail) -ForegroundColor Red }
    return 1
}

# Проверка подписи SignApk: комментарий zip + RSA/SHA-1 по сертификату из пакета.
function Test-Signature([string]$zipPath) {
    $result = [pscustomobject]@{ Ok = $false; Detail = '' }
    try {
        $bytes = [System.IO.File]::ReadAllBytes($zipPath)
        $n = $bytes.Length
        if ($n -lt 64) { $result.Detail = 'файл слишком мал'; return $result }
        $commentSize = [int]$bytes[$n-2] + ([int]$bytes[$n-1] -shl 8)
        if ($commentSize -le 6 -or $commentSize -ge $n) {
            $result.Detail = 'нет подписи (zip без комментария)'
            return $result
        }
        $commentStart = $n - $commentSize
        $magic = [System.Text.Encoding]::ASCII.GetString($bytes, $commentStart, 17)
        if ($magic -ne 'signed by SignApk') {
            $result.Detail = 'комментарий не от SignApk'
            return $result
        }
        $sigStart = [int]$bytes[$n-6] + ([int]$bytes[$n-5] -shl 8)
        if ($bytes[$n-4] -ne 0xFF -or $bytes[$n-3] -ne 0xFF) {
            $result.Detail = 'битый футер подписи'
            return $result
        }
        $derStart = $n - $sigStart
        $derLen = $sigStart - 6
        $signedLen = $n - $commentSize - 2
        $eocd = $commentStart - 22
        if ($eocd -lt 0 -or $bytes[$eocd] -ne 0x50 -or $bytes[$eocd+1] -ne 0x4B) {
            $result.Detail = 'EOCD не найден'
            return $result
        }

        Add-Type -AssemblyName System.IO.Compression.FileSystem
        $z = [System.IO.Compression.ZipFile]::OpenRead($zipPath)
        try {
            $entry = $z.GetEntry('META-INF/com/android/otacert')
            if (-not $entry) { $result.Detail = 'в пакете нет otacert'; return $result }
            $sr = New-Object System.IO.StreamReader($entry.Open())
            $pem = $sr.ReadToEnd()
            $sr.Close()
        } finally {
            $z.Dispose()
        }
        $b64 = ($pem -replace '-----BEGIN CERTIFICATE-----', '' -replace '-----END CERTIFICATE-----', '') -replace '\s', ''
        $certBytes = [Convert]::FromBase64String($b64)
        $cert = New-Object System.Security.Cryptography.X509Certificates.X509Certificate2(,$certBytes)
        $sha = [System.Security.Cryptography.SHA256]::Create()
        $fingerprint = ([BitConverter]::ToString($sha.ComputeHash($certBytes)) -replace '-', '')
        if ($fingerprint -ne $expectedCertSha256) {
            $result.Detail = "сертификат пакета не наш ($fingerprint)"
            return $result
        }

        $rsa = [System.Security.Cryptography.X509Certificates.RSACertificateExtensions]::GetRSAPublicKey($cert)
        $keyBytes = [int]($rsa.KeySize / 8)
        if ($derLen -lt $keyBytes) { $result.Detail = 'подпись короче ключа'; return $result }
        $sig = New-Object byte[] $keyBytes
        [Array]::Copy($bytes, $derStart + $derLen - $keyBytes, $sig, 0, $keyBytes)
        $data = New-Object byte[] $signedLen
        [Array]::Copy($bytes, 0, $data, 0, $signedLen)
        $ok = $rsa.VerifyData($data, $sig,
            [System.Security.Cryptography.HashAlgorithmName]::SHA1,
            [System.Security.Cryptography.RSASignaturePadding]::Pkcs1)
        $result.Ok = [bool]$ok
        $result.Detail = if ($ok) { 'подпись SignApk, ключ platform' } else { 'подпись не сходится' }
        return $result
    } catch {
        $result.Detail = "ошибка проверки подписи: $($_.Exception.Message)"
        return $result
    }
}

# ----------------------------------------------------------- source zip -----

if (-not (Test-Path $Zip)) {
    Write-Host "Не найден update.zip рядом со скриптом: $Zip" -ForegroundColor Red
    Write-Host 'Положите update.zip в эту папку и запустите снова.' -ForegroundColor Yellow
    exit 1
}
$Zip = (Resolve-Path $Zip).Path
$shaFile = "$Zip.sha256"
$expectedHash = ''
if (Test-Path $shaFile) {
    $expectedHash = ((Get-Content $shaFile -Raw) -split '\s+')[0].Trim().ToUpperInvariant()
}

# --------------------------------------------------------------- target -----

if ($useRoot) {
    $rootPath = (Resolve-Path $Root).Path
    $osDir = Join-Path $rootPath (Join-Path $folderName 'OS')
    $dest = Join-Path $osDir 'update.zip'
    Write-Host "Проверка папки: $rootPath"
} else {
    if (-not $Drive) {
        $drives = @(Get-RemovableDrives)
        if ($drives.Count -eq 0) {
            Write-Host 'Не найдено съёмных дисков. Вставьте флешку и запустите снова.' -ForegroundColor Red
            exit 1
        }
        Write-Host 'Доступные съёмные диски:'
        foreach ($d in $drives) {
            Write-Host ("  {0}:  {1}  {2} ГБ  свободно {3} ГБ  {4}" -f $d.Letter, $d.Label, $d.SizeGB, $d.FreeGB, $d.Fs)
        }
        $Drive = Read-Host 'Введите букву диска (например G) и нажмите ENTER'
        if (-not $Drive) {
            Write-Host 'Буква диска не введена — выходим, ничего не трогаем.' -ForegroundColor Yellow
            exit 1
        }
    }
    $Drive = $Drive.Trim().TrimEnd(':').ToUpperInvariant()
    $vol = Get-VolumeInfo $Drive
    if (-not $vol) { Write-Host "Диск $Drive`: не найден" -ForegroundColor Red; exit 1 }
    if ($vol.DriveType -ne 2) { Write-Host "Диск $Drive`: не съёмный — отказываюсь форматировать" -ForegroundColor Red; exit 1 }
    if ($vol.Size -gt 68719476736) {
        Write-Host 'Диск больше 64 ГБ. Отформатируйте его в FAT32 вручную (fat32format) и запустите с -VerifyOnly.' -ForegroundColor Red
        exit 1
    }

    Write-Host ''
    Write-Host ("Диск {0}: {1}, {2} ГБ, файловая система {3}" -f $Drive, $vol.VolumeName, [math]::Round($vol.Size/1GB,1), $vol.FileSystem) -ForegroundColor Yellow
    $rootPath = "$Drive`:\"
    $osDir = Join-Path $rootPath (Join-Path $folderName 'OS')
    $dest = Join-Path $osDir 'update.zip'
}

# --------------------------------------------------------------- prepare ----

if (-not $VerifyOnly) {
    if ($useRoot) {
        New-Item -ItemType Directory -Force -Path $osDir | Out-Null
    } else {
        if (-not (Test-Admin)) { Write-Host 'Для форматирования нужны права администратора. Запустите write-usb.bat.' -ForegroundColor Red; exit 1 }
        if ($vol.Size -gt 34359738368) {
            Write-Host 'Диск больше 32 ГБ: Windows может не отформатировать его в FAT32. Если не выйдет — используйте fat32format.' -ForegroundColor Yellow
        }
        Write-Host ''
        Write-Host 'ВНИМАНИЕ: все данные на флешке будут удалены.' -ForegroundColor Red
        $answer = Read-Host 'Введите слово FORMAT и нажмите ENTER'
        if (($answer.Trim().ToUpperInvariant()) -ne 'FORMAT') {
            Write-Host 'Отменено (слово FORMAT не введено).' -ForegroundColor Yellow
            exit 1
        }

        Write-Host 'Форматирование в FAT32...'
        Format-Volume -DriveLetter $Drive -FileSystem FAT32 -NewFileSystemLabel 'EX2TOOLS' -Confirm:$false -Force | Out-Null
        $vol = $null
        for ($i = 0; $i -lt 10; $i++) {
            $vol = Get-VolumeInfo $Drive
            if ($vol -and $vol.FileSystem -eq 'FAT32') { break }
            Start-Sleep -Milliseconds 500
        }
        if (-not $vol -or $vol.FileSystem -ne 'FAT32') {
            Write-Host "После форматирования ФС = $($vol.FileSystem), ожидалась FAT32" -ForegroundColor Red
            exit 1
        }
        Write-Host 'Форматирование: OK' -ForegroundColor Green
        if ($vol.FreeSpace -lt (Get-Item $Zip).Length + 10MB) {
            Write-Host 'На флешке недостаточно места.' -ForegroundColor Red
            exit 1
        }
        New-Item -ItemType Directory -Force -Path $osDir | Out-Null
    }

    Write-Host "Копирование: $Zip -> $dest"
    Copy-Item $Zip $dest -Force
    if (-not $useRoot) {
        try { Write-VolumeCache -DriveLetter $Drive -ErrorAction Stop } catch { Start-Sleep -Milliseconds 800 }
    }
}

# ---------------------------------------------------------------- verify ----

Write-Host ''
Write-Host 'Проверка результата:' -ForegroundColor Cyan

if ($useRoot) {
    Check 'Папка для проверки существует' (Test-Path $rootPath) $rootPath
} else {
    $vol = Get-VolumeInfo $Drive
    Check 'Файловая система FAT32' ($vol -and $vol.FileSystem -eq 'FAT32') ("ФС: " + $(if ($vol) { $vol.FileSystem } else { '—' }))
}

Check "Папка $folderName\OS существует" (Test-Path $osDir) $osDir
Check 'Файл OS\update.zip существует' (Test-Path $dest) $dest

if (Test-Path $dest) {
    $item = Get-Item $dest
    Check 'update.zip меньше 4 ГБ (FAT32)' ($item.Length -lt 4294967296) ("{0:N0} байт" -f $item.Length)

    $dstHash = (Get-FileHash $dest -Algorithm SHA256).Hash.ToUpperInvariant()
    if ($expectedHash) {
        Check 'SHA-256 совпадает с update.zip.sha256' ($dstHash -eq $expectedHash) $dstHash
    } else {
        $srcHash = (Get-FileHash $Zip -Algorithm SHA256).Hash.ToUpperInvariant()
        Check 'SHA-256 совпадает с исходным update.zip' ($dstHash -eq $srcHash) $dstHash
    }

    $sig = Test-Signature $dest
    Check 'Подпись пакета (ключ platform)' $sig.Ok $sig.Detail

    try {
        Add-Type -AssemblyName System.IO.Compression.FileSystem
        $z = [System.IO.Compression.ZipFile]::OpenRead($dest)
        try {
            $names = @($z.Entries | ForEach-Object { $_.FullName })
            foreach ($required in @(
                    'META-INF/com/google/android/update-binary',
                    'META-INF/com/google/android/updater-script',
                    'META-INF/com/android/otacert',
                    'META-INF/com/android/metadata',
                    'data/local/tmp/ex2_pkg_entry',
                    'data/local/tmp/ex2_pkgdb.sh')) {
                Check "В пакете есть $required" ($names -contains $required)
            }
            $apks = @($names | Where-Object { $_ -match '^data/app/.+/base\.apk$' })
            Check 'В пакете один base.apk' ($apks.Count -eq 1) ($apks -join ', ')
            Check 'Пакет для com.ex2tools.iv' ($apks.Count -eq 1 -and $apks[0] -eq 'data/app/com.ex2tools.iv-1/base.apk')
            $zipOk = $true
        } finally {
            $z.Dispose()
        }
        Check 'Пакет читается без ошибок' $zipOk
    } catch {
        Check 'Пакет читается без ошибок' $false $_.Exception.Message
    }
}

$rootItems = @(Get-ChildItem $rootPath -Force -ErrorAction SilentlyContinue |
    Where-Object { $_.Name -notin @('System Volume Information', $folderName) })
Check 'В корне флешки нет лишних файлов' ($rootItems.Count -eq 0) (($rootItems | ForEach-Object Name) -join ', ')
$osItems = @(Get-ChildItem $osDir -Force -ErrorAction SilentlyContinue |
    Where-Object { $_.Name -ne 'update.zip' })
Check 'В папке OS только update.zip' ($osItems.Count -eq 0) (($osItems | ForEach-Object Name) -join ', ')

$code = Show-Summary
if (-not $VerifyOnly) {
    Write-Host ''
    Write-Host 'Извлеките флешку безопасно, затем в машине:' -ForegroundColor Cyan
    Write-Host '  1) вставить USB и дождаться «USB подключён»;'
    Write-Host '  2) Телефон -> секретный код -> U盘升级;'
    Write-Host '  3) дождаться строки [EX2] OK: package registered, reboot required;'
    Write-Host '  4) удерживать кнопку «предыдущий трек» 15 секунд.'
    Write-Host 'Строка «Installation aborted» в конце — это норма.'
}
exit $code
